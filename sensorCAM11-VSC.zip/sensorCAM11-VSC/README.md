# Video Based Multi Channel Position Sensing Camera
## Introduction
This single camera is capable of replacing up to 80 detectors/sensors on a model railroad along with their extensive wiring.
As it is a cheap device, on large railroads, several cameras can be used for adequate coverage. 
It can detect, and be used to control, train movements without any trackside sensors at all.
Used in conjunction with an i2c bus to a DCC-EX Command Station, the options through X-RAIL automation seem unlimited.
It does not include loco or rolling stock identification.

## Hardware
### Base Processor Module
The Camera is a standard ESP32-CAM with an ESP32-CAM-MB (CH-340G based) to add USB capability and, in it's simplest form, a PCA9515A i2c interface module.
To connect the sensorCAM to i2c, some limited soldering is required to connect the PCA9515A (5 wires) to the USB MB on the CAM.
An advanced proto-daughter board is preferable to the PCA9515, to include long i2c buffering (up to 30metres), an isolated power supply, and indicator LEDs.
A cheap commercial aerial may be useful in marginal WiFi situations.

### Camera Module
The sensorCAM uses the 32bit ESP32-S microcontroller with an OV2640 camera module.  
It is fitted with a 4Mbyte PSRAM for image storage and a built in WiFi aerial.
It also has 3Mb of available program storage, EPROM memory for parameters, and 327kbytes of dynamic memory. 

## Software requirements
The Arduino IDE is recommended for the sensorCAM and, if used, the connected EX-Command Station DCC-EX-CS software with EX-RAIL.
The ESP32-CAM has an Arduino library of software that is needed to enable the camera image manipulation and the WiFi imaging of the railroad.
In addition, the Processing 4 application is highly desired to enable railroad images to be captured and sensor positions to be located and seen, as the Arduino IDE cannot give visual feedback.
* https://processing.org/

The webserver WiFi images are not a substitute for the Processing 4 utility, as sensorCAM cannot "sense" in webserver mode.
Specific SensorCAM files are provided for each of the above apps.

NOTE: For enhanced versions, rather than "main/master" branch, use a recent "devel" version of Command Station (5.2.88+) and "devel" branch of sensorCAM (3.10+)

## Documentation
The sensorCAM is a complex device needing some in depth understanding to achieve its full potential.
A 30 page manual is provided to assist with this process.

If you want clarification or wish to discuss the implementation please contact me on Discord (@Barryd) or at bcdaniel2@optusnet.com.au and I will attempt to address your issues.  I welcome your feedback. 

## Outline of install process
1.	Acquire ESP32-CAM and MB/FTDI
2.	install Arduino IDE with the ESP32 libraries (includes a WiFi CAM example)
3.	Load the CAM with the WiFi example and test.
4.	Install the sensorCAM.ino software and configure.
5.	Test the basic sensorCAM functions to confirm functional install
6.	Load Processing 4 app. and sensorCAM.pde code
7.	Use the Processing 4 app to replace the Arduino Monitor.  Familiarize and test
8.	Create test sensors and test detection with moving targets
9.	Setup the CAM viewing the model railroad and test a virtual sensor with moving rolling stock.
10.	Optimise parameters for best performance.
11.	Connect CAM to an i2c interface (e.g. PCA9515A or better)
12.	Depending on system, integrate sensorCAM into Command Station using appropriate code.

For a detailed 12 step guide refer to the InstallationGuide.pdf document.




  