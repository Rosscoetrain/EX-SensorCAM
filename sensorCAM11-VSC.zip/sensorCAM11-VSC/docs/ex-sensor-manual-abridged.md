# EX-SensorCAM Abridged Manual

Including ESP32-WROVER-CAM and ESP32-WROOM-S3 CAM's

<!-- ==TODO== MEDIUM - change the references on this page from the Arduino IDE to VSC/PIO -->

## CONTENTS

[1. Overview](#1-overview)  
[2. ESP32-CAM](#2-esp32wrover-cam)  
[3. Physical Installation](#3-physical-installation)  
[4. Notation](#4-notation)  
[5. Configuration](#5-configuration)  
[6. PROCESSING4 monitor/console](#6-processing4-monitor)  
[7. Wiring Requirements](#7-wiring-requirements)  
[8. Host Communication](#8-host-communication)

## Appendix

[A. ESP32 sensorCAM Command Summary](#appendix-a)  
[B. Check List for Optimising Sensor Response](#appendix-b)  
[C. Parsed DCC EX-CS sensorCAM commands](#appendix-c)  
[E. Tabulated DCC-EX-CS id's for sensorCAM](#appendix-e)  
[F. Hardware Interface (LTC4311 & Endpoints)](#appendix-f)  
[H. Notes on use of EX-Rail with SensorCAM](#appendix-h)  
[J. WROVER-CAM notes](#appendix-j)  
[K. OV2640 Lens options and geometry](#appendix-k) 

## 1. Overview

The sensorCAM is a video camera replacement for physical proximity sensors/detectors on a model railroad/railway. It can replace up to 80 detectors and their associated power and signal wiring using artificial vision alone. It offers the flexibility of sensor placement or relocation instantly by software command with no physical layout modification.The railroad/railway can be automated using artificial vision of train activity. Each virtual sensor can produce a logical state of 1 (occupied) or 0 (unoccupied) and is readable over an i2c cable. SensorCAM originally used the ESP32-CAM module. However, the ESP32-WROVER-DEV CAM (v1.6) is the preferred substitute with potentially simpler setup.

The sensorCAM takes 10 frames per second in RGB565 format at QVGA resolution of 240 x 320. Each sensor consists of a square group of 16 pixels which equates to approximately 20x20mm square with the standard lens at 1500mm. The software decodes and saves only the 80 sensor images (1280 pixels) and then compares each sensor image with a reference image prerecorded either at startup, on request, or by a "recent" automatic update. If the images do not match the references well, then the sensor is "tripped" or "occupied" & status '1' is registered. A good match results in '0' output. The state of virtual sensors can be manually monitored on the USB monitor, or polled by microcontroller over the i2c interface cable.

!!! note "Note:"
    The sensorCAM is sensing only when the Flash LED is pulsing at 10Hz (for each new frame).

![ESP32 CAM with MB](../../_static/images/ex-sensorcam/esp32-cam-with-mb.png){ width=500px }

2PCS ESP32-CAM-MB, ESP32-CAM Board, Micro USB to Serial Port CH-340G with OV2640 2MP Camera Module 4MB PSRAM

![ESP32 Wrover CAM](../../_static/images/ex-sensorcam/esp32-wrover-cam.png){ width=400px }

!!! note "Note:"
    While the full manual primarily talks about the ESP32-CAM-MB, the focus here is the alternative in the newer **ESP32 WROVER-CAM** single board option. For some further preliminary details refer to Section 7 Wiring, **Figure 6**.  The software is identical for both CAMs.

    Dealing with video images involves complexities not normally associated with model railroading sensors. The sensorCAM is a complex device with a number of commands explicitly for setup and evaluation. In addition to these, several "output" commands can be used by a host to interrogate the "virtual sensor" output states. The initial setup can be somewhat involved and requires familiarity with many of the 25 commands discussed below.

The sensorCAM has two ***mutually exclusive modes*** of operation; the sensorCAM mode and the webCAM mode. The webCAM mode is essentially as described in the on-line tutorials. Use that mode only for education and alignment. Invoke webCAM video mode by issuing the **v1** (or **v2**) sensorCAM command to get a webCAM URL (e.g.192.168.0.64)

The WROVER-CAM has USB integrated.  The WROVER or MB is far simpler to use than a separate FTDI used in the videos.

The ESPRESSIF guide will show how to install the Arduino-ESP32 support.

[Installing Arduino-ESP32 2.0.6 documentation (readthedocs-hosted.com)](https://espressif-docs.readthedocs-hosted.com/projects/arduino-esp32/en/latest/installing.html#installing-using-arduino-ide)

A tutorial on setting up the ESP32 on Arduino IDE is available on YouTube

[ESP32 CAM-10 Dollar Camera for IoT Projects](https://www.bing.com/videos/search?q=ESP32+CAM+-+10+Dollar+Camera+for+loT+Projects+-+YouTube&view=detail&mid=77BF6363644D71DF685B77BF6363644D71DF685B&FORM=VIRE)

[Introduction to ESP32- Getting Started](https://www.youtube.com/watch?v=xPINTk3VLQ)

The sensorCAM software is uploaded to the ESP32-CAM using the Arduino IDE. The sensorCAM has been programmed with two modes of operation; a webCAM mode (as in the on-line tutorial) and a sensorCAM mode. The limited power of an ESP32 prevents both functioning at the same time. Consequently, to see an image of the railway while sensorCAM is operational requires a third application (Processing 4.3) to retrieve a still image from the CAM over the USB cable to a computer. The Processing 4 *sensorCAM.pde* app replaces the Arduino IDE and IDE monitor retaining the sensorCAM command set and offering a (slow) image capture capability over USB cable. Processing 4 allows virtual sensors to be placed interactively on an image of the railway with a simple mouse click.

In addition to the USB interface, you may need a daughter board (e.g. ESP32S 38P/V4/Expansion Board), "perf" board or prototyping board to connect to the real world (power, indicators, control wires, and i2c.) Further details are given below. However to test the sensorCAM functions, one only needs the CAM with a USB interface, with power from the PC's USB port.  The Wrover Cam minimises this need.

To control a railway, the layout needs a microcontroller based management system. This typically could be an Arduino Mega (or **EX-CSB1**) based system running software such as the DCC-EX CommandStation and EX-RAIL automation application. The **EX-CommandStation**(CS) includes a sensorCAM specific driver as detailed later.

## 2. ESP32/WROVER-CAM

The heart of the sensorCAM is the ESP32 CAM module with an ov2640 camera sensor and a 32bit ESP32-S microprocessor. The sensorCAM software/sketch is loaded into the ESP32 using the Arduino IDE over a USB port with settings newline/115200 baud. Follow the installation guide and run the camera example first, to get a demo webserver and CAM operational with a simple coloured test image. Experiment with settings to "get a feel" for the parameter effects. The CAM has a considerable number of video related on-screen settings, but you should find the defaults adequate. The standard ov2640 can see some Infra Red light which may be utilised to see a bright IR LED as a beam-break sensor.

![ESP32 CAM Example Sketch](../../_static/images/ex-sensorcam/esp32-cam-example-sketch.png){ width=600px }  
 &nbsp; &nbsp; **Figure 1. &nbsp; webCAM mode**

**Figure 1.** is an example of the standard webCAM browser presentation. It is a very useful mode for alignment and as a training aid in investigating the effects of the many video adjustments possible, but does not allow placement of sensors as sensorCAM mode can not be simultaneously enabled.

The sensorCAM uses QVGA but VGA is better in webCAM mode. These settings can be changed after the CAM images are stable, but the default values should be adequate.

If you "Start Stream", parameter changes will seem almost immediate. But with "stills", after changing a variable, you may have to click "Get Still" 3 times to clear the pipeline and get a changed image. In Stream mode, close observation will reveal changing whole image brightness/colour for several seconds after image disturbance (e.g. a hand in front of CAM) as the auto adjustments "correct" the image. These types of changes can trip the sensorCAM even if the obstruction does not block the virtual sensor. Consequently after power-up, the sensorCAM may stabilize and then turn off some auto adjustments in the first 15 seconds. Changing environment lighting may result in a need to use a "re-reference" command, for example perhaps after sunset or turning on extra lighting.

Due to the slowness of the ESP32 & WiFi, the "live stream" is slow and a webCAM delay in response will be observed.  The delay is inevitable in webCAM WiFi mode.

![ESP32 CAM Example Capture Sample](../../_static/images/ex-sensorcam/esp32-cam-example-capture-sample.png)  
 &nbsp; &nbsp; **Figure 2 &nbsp; Initial sensorCAM settings**

After the sensorCAM has booted up, it reads frames for 9 seconds before automatically doing a reference grab for all defined sensors (the **r00** command).

The ESP32-CAM has an Infra-Red(IR) filter to enhance colour response. The sensorCAM relies on strong colour contrast(saturation) to detect changes. Low lighting levels and poor contrast degrades performance.  Some IR penetrates, so the CAM may use an IR LED for reliable beam-break sensing.

To run the sensorCAM.ino, it will be necessary to configure the Arduino IDE for the ESP32 as covered in the above you-tube tutorial links. Load and run the demonstration. For the sensorCAM, you will require new files as described in the sensorCAM installation Guide.

The ESP32-CAM can take rgb565 frames at 13/second. However it is a 3 step process; image sensing, processing and storing. It will then take further cycles to assess the state of the 80 virtual sensors in the frame(another two cycles) A total of 5 cycles places a significant limit on the sensorCAM speed of response time (up to 0.5 seconds at 10 frames/second). A fast HO loco can travel 160mm @ 100kph, so this latency might need to be accommodated in planning virtual sensor locations.

## 3. Physical Installation

For testing purposes you will need a computer with a spare USB port and the Arduino IDE software installed. The PROCESSING 4 software is also advisable as it gives a more reliable and convenient image for setup. A long powered USB cable (5m?) may be an advantage as the sensorCAM may be some distance from the PC. For a final installation the sensorCAM would be connected via a cat5/6 cable carrying power and an i2c bus (of up to 30m) to a Command Station or similar. Some different practical wiring solutions are explored in [Appendix F](#appendix-f).

!!! note "NOTE: 5volt Command Stations"
    A 5 volt Command station or i2c bus will need a 5V to 3.3V level shifter such as PCA9515A.  Refer to the full manual [Wiring Requirements](ex-sensor-manual.md#7-wiring-requirements) for further details.

 The sensorCAM is preferably placed above and square-on to a section of layout at a height of 1 to 1.8m above the surface. 1.2m gives a max. coverage of approximately 1.2 x 0.9m with the standard(66) lens. Tilting the CAM by up to 30 degrees can increase the layout coverage by up to 50%. Refer to [Appendix K in full manual](ex-sensor-manual.md#appendix-k) for further options.

Lighting is critical for reliable operation. The lighting should be steady. Both LED flood and Fluorescent lighting might degrade results due to the flickering levels of illumination at 100/120 Hz. Use quality LED lights. The light fittings should not be visible in the camera's field of view. A uniform level of lighting is the objective, with a minimum influence from fluctuating daylight, fans or direct sun and cloud shadows through windows. Some experimentation may be needed to avoid local "glare".  Bright lighting is desirable (good quality LEDS) to enhance colour differentiation. Check your lighting for flicker by taking a "slo-mo" test video on a cell phone. Fluoros are bad!

The CAM mount needs to be rigid to avoid vibration which may trip sensors due to small image movements. It also needs to have a suitable route for a (cat5) cable for its own power supply and the necessary i2c communications. The length of this cable needs to be considered if the railway's i2c network is otherwise long. The quick connection above (using PCA9515A) is for short lengths only (i2c under 3m). Up to 7m may be achieved using 2k pull-up resistance and one LTC4311 "terminator" to enhance signal rise time.  The recommended alternative for longer cables is the Sparkfun differential Endpoint system.  Power should be regulated near the remote sensorCAM if not using a short USB cable.

Most reliable results may be obtained with light grey coloured ballast and darker sleepers. If results are inadequate, light green (grass?) or yellow "reflectors" between the rails may relieve any problem (recommended in fiddle yards). If lighting throws shadows beside targeted rolling stock, the shadows may be used advantageously by good sensor placement.

For initial configuration, access to the sensorCAM's USB port is important. Loading computer code over a long USB cable is problematic, but monitoring and tweaking settings may be done with a reduced BAUD rate or a (5m?) buffered USB cable at 115200 BAUD.

With regards lighting, fluorescent or LED lighting normally flickers at twice mains frequency so it pulses at 100 or 120Hz. Tolerable to humans, but it can be seen in a sensorCAM image on a uniformly white test panel as below (**Figure 5**). In 100mSec there could be up to 10 bands in one image.  the faint bands will drift across the sensors and potentially trip them in the worst case scenario. Set the threshold high enough to avoid such trips or (better) change lighting. **Figure 4** shows an example of bad 100Hz banding.

![Test Image with Light Banding](../../_static/images/ex-sensorcam/test-image-light-banding.png){ width=600px }  
 &nbsp; &nbsp; **Figure 4 &nbsp; Test image showing fluorescent or LED light banding**

## 4. Notation

The notation used in all sensorCAM reference material uses symbols according to the following convention:

**%**&nbsp; &nbsp; &nbsp; used to designate a digit as part of a bank/sensor designator in bsNo style. i.e. 0/2, b/s or %/% or %%  
**\#** &nbsp; &nbsp; &nbsp; used to designate a digit as part of a decimal number as in ### for a 3 digit decimal number.  
**$** &nbsp; &nbsp; &nbsp; used to designate a single alphanumeric character(0-9 or A-Z) depending on context.  
**S** &nbsp; &nbsp; &nbsp; Capital S may be used to refer to a specific sensor such as S02 for example. Designation format: S%%  
**[ ]** &nbsp; &nbsp;&nbsp; Square brackets may be used to indicate optional command arguments(don't include[ ] in command).

Sensor "bsNo." number consists of two digits preferably written separated by a '/' as in 1/2 but in commands this is reduced to 12 as in command **i12**. Command 'i' has the form **i%%** indicating it requires a 2-digit bsNo. As 49 is an invalid bsNo.(s range is 0-7), i49 is invalid. Some commands require a DECIMAL number and are expressed as having form **t##** for example. **t49** is therefore a valid command. The '**m**' command takes the form **m$,##** requiring a single digit and a 2-digit decimal number. For more details on commands see see [APPENDIX A](#appendix-a)
.

Where bsNo.'s are printed, they can take several equivalent forms depending on context. Where possible they are printed as %/% e.g. 2/3. However an equivalent form is 023. Any printed sensor number starting with a '0' can be treated as equivalent to the '/' form so Sensor 023 == 2/3 == bank 2 sensor 3. The 0%% form is in fact the "OCTAL" format of bsNo. (Note: 087 and 097 are invalid. Keeping usage to banks ranging from 0 to 7 avoids any confusion).

!!! note "Note:"
    Some diagnostic output (e.g. **f%%**) may resort to another numbering system (i.e. HEXADECIMAL) for compactness, but for normal usage this notation is generally avoided. Just be aware of the context in which numbers are being used.

Where words are in *italics*, these are the actual names used in the C++ programs for sensorCAM. Consequently they may seem cryptic, but their function is hopefully clear.

## 5. Configuration

### 5.1 Plan numbering strategy

The first step is to decide a sensor distribution strategy & numbering strategy (not set in stone) . A sensorCAM has 10 banks (0-9) of eight (0-7) individual sensors available (total 80). Each **bank** can be tested as a whole to see if ANY sensors tripped or NO sensors tripped. Also placing a string of sensors in a row, for example along a platform, can indicate train position with the binary bank value increasing as the train approaches a signal as it crosses sensors 0 through 7. (see **Figure 5** for examples) Sensors are generally referred to with a two digit bank/sensor designation (their bsNo.) e.g. Sensor 68 and 69 are therefore invalid bs numbers, 97 is valid. Use one bank for a platform (set of 8 sensors). Sensor **S00** is reserved as a brightness reference sensor. Sensor **S06** is also RESERVED for now. It is suggested that user's Sensors start with bank 1, i.e. S10, S11 & upwards, with related sensors in their own bank. They do NOT need to be sequential (Follow the installation Guide for full details). **With the recommended definitions set up, the user does not need to remember or refer to vPins for sensorCAM sensors at all - just use the S%% identifier.**

For an **EX-CommandStation** (CS), the 80 sensors will have vPin numbers ranging from #00 to #79 (DECIMAL) and mapped to 80 b/s id's(S00 to S97). Users can use, for example, ``AT(CAM 0%%)`` in **EXRAIL** commands where a vPin ID is called for.  For the technically minded, CS invisibly calculates vPin=BasePin+bx8+s.

### 5.2 Preset the WiFi settings

Before uploading the software into CAM, check that it has the appropriate WiFi definitions for your railway *WIFI_SSID* & *WIFI_PWD*, and perhaps for your test area *ALTWIFI_SSID* & *ALTWIFI_PWD* are in your ***configCAM.h*** file.

### 5.3  Other configCAM settings

 &nbsp; &nbsp; a) set i2c address appropriately (0x11-0x14) e.g. *#define I2C_DEV_ADDR&nbsp;0x11*   
 &nbsp; &nbsp; b) If using WROVER,  *#define CAMERA_MODEL_WROVER_KIT* //(ver316+)<br>
 &nbsp; &nbsp; c) If you want to use "larger" sensors, *#define SEN_SIZE 2* //range (0-7)  

### 5.4 Load sensorCAM software

Follow you-tube to pre-configure the Arduino IDE for ESP32.  Using this IDE, load the software into sensorCAM with it unmounted. Then mount the CAM in a suitable place for tests. A long USB cable is problematical.

### 5.5 Establish a monitor screen

Establish a USB connected monitor (e.g. Arduino IDE monitor, or PROCESSING4 monitor, preferably at 115200 baud. The PROCESSING 4 monitor coded for the sensorCAM has the advantage of displaying the CAM's railroad/railway image (or selected part thereof), albeit rather slowly!). Because of the many changeable CAM parameters, the WiFi link (webCAM) is not a reliable indicator of the sensorCAM image quality. It may be better or worse. The PC (using Arduino IDE) is only able to show images via WiFi, but because the sensorCAM runs on RGB565 format it cannot send WiFi (jpeg) images without rebooting into WiFi/jpg webCAM mode (under which it cannot read sensors!). The reboot/display/reboot cycle for WiFi webCAM is also tediously time consuming.

The sensorCAM takes some time to boot and establish sensing mode. The flash LED starts flashing on every frame after about 10 seconds and data flows to the USB terminal. A period of averaging ensues with "good" sensing by about 30 seconds. This flow of data (and sensing) can be suspended with the '**w**' (wait) monitor command. Some commands (including a blank line entry) will subsequently restart the sensing camera and sensor output. The CAM may crash if it is left waiting for input for over 30 minutes. Reference images would also be long out of date.  
**Note: t1** toggles output scrolling data ON/OFF without suspending either flashing or sensing.

### 5.6 Verify WiFi webCAM ops

The CAM can be switched to webCAM WiFi video mode with the '**v1**' command. '**v2**' can select your alternate WiFi network. ('**v**' will give sensorCAM software version). '**v1**' (or '**v2**') will reboot and load webCAM mode connecting to the network selected, and providing a URL e.g. http://192.168.0.xx that can be used to connect with a browser. An image, like **Figure 1** above, should be seen with controls for experimenting with Brightness etc. This image is educational and useful for camera alignment, but not necessarily a good indication of the sensorCAM (sensor mode) image because of the unpredictable parameter effects. To see a more reliable image, run the PROCESSING 4 *SensorCAM.pde* monitor instead of Arduino webCAM example (refer [Section 6](#6-processing4-monitor)). To exit video mode, try the monitor command **``R``** (or **``F``**). If this software reset fails, try manually rebooting the sensorCAM (power OFF/ON or via the on-board RST push-button using a non-metallic tool!).

### 5.7 Command Familiarisation

Review the sections below (**5.8 etc.**), before mounting the camera over the railroad/railway, as it is advisable to be familiar with the sensorCAM command set. The setup commands will have to be repeated accurately once the CAM is mounted in its final location (Step 5. Installation Guide).

### 5.8 Sensor placement

Setting up the CAM first requires locating sensors. When deciding on sensor location, be aware that the sensor response is slow compared to conventional sensors. Allowing for 500mSec delay, which at 100kph equates to 150mm of travel (in HO), may influence sensor placement. Best performance is obtained if the sensors are not within 20 rows/columns of an image edge. Remember to save to EPROM with the 'e' command once satisfied. Virtual sensor location can be set up in several ways. Option d. is preferred.

**a.** &nbsp; Automatic loading from EPROM on boot-up. This is only applicable after an initial sensor set has been established and command ``e` used to save them to EPROM.

**b.** &nbsp; The bright LED method: Place a bright LED at the required location and reduce room lighting if needed.  Issue an ``s%%`` command (e.g. S00 for an off-track reference sensor) and wait for the CAM to scan and locate the LED and setup sensor coordinates. Remove the LED, restore lighting, and perform an ``r%%`` for new reference images.

**c.** &nbsp; Issue a ``k%%,rrr,xxx`` command to place sensor %% at CAM pixel position rrr(row) and xxx(column). This method is most useful for "tweaking" coordinates if you want to adjust the result of the LED method. The CAM has 240 rows/lines of 320 pixels each, numbered from 0. Use the ``i%%`` command for info. on sensor S%%.  **NOTE:** Use **``k``** to set up test sensors initially, but delay setting final positions until Processing 4 installed and enhanced GUI **``k``** and **``a``** available. The ``a`` command does 3 commands in one (i.e. `k`, ``a`` (enable) & ``r``*).

**d.** &nbsp; Running Processing 4, an image can be downloaded, a bsNo. nominated by typing **``k%%``** (or **``a%%``**) and the mouse click on the image appends coordinates to **``k%%``**. Press Enter if the command is complete and correct. Similarly, the long version of **``a%%``** sets position, enables, and records a reference all in one command.

### 5.9 Sensor status and save

Once a sensor has been located, the **``p$``** command can show/tabulate all defined positions up to bank$. To enable a sensor use the **``a%%``** command. This will enable AND record a new reference image for the sensor. It will then be included in the screen "data dump". Only "enable" sensors when UN-occupied, or do an **``r%%``** later when the sensor is empty. Also, remember to do an **``e``** command when you want to save positions in EPROM for next time.

### 5.10 Set a Sensor Threshold

A threshold needs to be set to define the level of difference in image required to register a sensor trip or "Occupation". This typically ranges from 40 to 60. Try **``t45``** for starters. Some fluctuating lighting and electrical "noise" needs to be tolerated, but a higher threshold reduces sensor sensitivity for dark-on-dark contrast in particular. If there are "noise" trips, adjust the threshold or min2trip a little higher. See [APPENDIX B](#appendix-b) for more.

### 5.11 Limit printout range

It is desirable to set (using ``m``) a *maxSensors* parameter (e.g. 030) to limit diagnostic printouts to a manageable screen width, and especially important to set the *min2flip* parameter which helps filter out noise trips. However *min2flip* slows the response to valid trips by 100mSec (frame rate) per extra count. Suggest settings of 2(default) or 3. e.g.**``m3,30``**. **Note:** *maxSensors* (pulled from EPROM) limits the following....

**a.** the data stream for console/monitor, limited to enabled sensors below *maxSensors* (and above *minSensors*)

**b.** histogram printout, to enabled sensors below *maxSensors* (see statistics command **``&``**)

**c.** the *boxlt()* sensor boxes seen on Processing 4 images, to enabled sensors below *maxSensors*

**d.** i2c buffer data for 't' record, to bsn's below *maxSensors* (and above *minSensors*)(sent to Command Station) The command **``t``** acts as a flag to prepare a packet of i2c data that the CS can reconstitute as per the USB ASCII data stream/scroll.

### 5.12 LED trip indicator EPROM

If you want a LED bank occupancy indicator on the CAM, use the **``n$``** command to cause a bank occupied LED to show (default Bank 2). *nLED, min2flip, maxSensors* and *threshold* can be saved to EPROM, along with sensor positions and twins (see **5.15** below) with the **``e``** command. *minSensors* (**``n10,%%``**) is not currently saved in EPROM.  You will of course have to add a resistor and LED to the physical CAM (GPIO14 or GPIO32).

### 5.13 Sensor reference refresh

Although sensor enabling (**``a``**) causes an immediate reference capture, it may be necessary to occasionally do a fresh reference capture for all sensors (make sure they are unoccupied!) by using the '**r00**' command. Individual sensor references can be refreshed using **``r%%``**. The results of a refresh can be seen in the scrolling "data dumps" of enabled sensors, their "difference scores" (32-99), and their perceived occupancy state. The sensor **S00** is constantly averaged and refreshed every 6.4 seconds. Furthermore, there is an automatic refresh process that cycles through enabled sensors and regularly averages 32 consecutive sample images.
If the sensor remains unoccupied, it updates the reference, compensating for slowly drifting lighting changes.

### 5.14 Scroll data interpretation

The scrolling data dump displays "SUS" (suspend) if auto updates are off. It also displays *threshold*(T), *min2trip*(M), the bank assigned to the on-board *nLED*(N), S00 reference diff. score, as well as the S00 reference brightness(R) and its current actual brightness(A), a brightness scale factor(B) and other enabled sensors. 'A' is the Actual latest sum of the 48 bytes of a sensor image (max 3024) and should be between 1200 and 2500 ideally. Following a reference refresh (**``r``**), for an unoccupied image, the (noisy) diff. scores should be 32-37. If references are being updated, a note will appear at the right hand side of the data dump in the form of "**Ref 0%%**" to indicate that a new reference for an UNOCCUPIED sensor has occurred. This dump allows for performance monitoring during commissioning.  
:**oo46##** indicates tripped sensor (## = **occupied**) sensor are shown by default with a central diff score (32-99).  
:**?-46-?** indicate an above threshold image **potentially occupied** (waiting for *min2trip*).  
:**oo47?T** indicates **suspected occupied** but no confirmation from Twin (see [5.15 in the full manual](ex-sensor-manual.md#515-second-opinions-twin)).

## 6 PROCESSING4 monitor

![Processing4 Monitor/Console with Image](../../_static/images/ex-sensorcam/processing4-console-image.png)  
 &nbsp; &nbsp; **Figure 5 &nbsp; Processing 4 Console and image window**
 &nbsp; &nbsp; &nbsp; Note: Sub-optimum 'c' settings caused green tint.

The Processing application displays the image using sensorCAM settings, and also shows colour coded sensors. As previously stated, the PROCESSING4 application is a crude USB monitor that enables the user to control and configure the sensorCAM with the additional benefit of being able to invoke a display of the image. All the sensorCAM commands can be used. At 115200 baud, a full RGB565 image takes 13 seconds, but it is often convenient to reduce this by prescribing a smaller image segment of limited rows and/or columns (e.g. **Y120** for lower half of a 240 row screen).  
The Processing 4 application can be [downloaded from here](https://processing.org)

The SensorCAM.pde code assumes the USB port for the sensorCAM is the lowest (*comNo=0;*) on the list displayed on startup. Should this not be the case, for example if another USB is being used to simultaneously run an IDE to a Command Station, then the *int&nbsp;comNo=0;* code line (line 15?) of the sensorCAM.pde will need to be increased to, for example, *int&nbsp;comNo=1;*  
You may also increase the image display window size factor by editing the next *final&nbsp;&nbsp;int&nbsp;&nbsp;SF=2;* line to *=3;* or *=4;* on high res. screens.

The sensorCAM Processing 4 monitor accepts commands **``W``**, **``X``**, **``Y``** & **``Z``** which allow the user to nominate a "strip" or subsection to image. e.g. **Z80 X240 Y** will update the last quarter image(columns 240-319) of the 240x320 pixels in 4 seconds. This quicker shortcut method enables, for example, comparison of quarter images under different lighting conditions by using different **X** values. Similarly **``W60``** **``Y120``** will produce a quarter image from row 120 to 179. Each part image is pasted over previous images. Each new image appears more quickly if only a subsection is specified this way. The next image can be flipped Vertically(y) and Horizontally(x) by using **``V``** &/or **``H``** before capture. The **Figure 5** image used  **``V H Y60``**  The values for V, H, W, X & Z are remembered for subsequent '**Yrrr**' commands so need not be repeated.  

The image will have enabled sensors (b/s) boxed and identified by a (resistor) colour code. Left bar is bank# and right bar is sensor#. Combined, they give the Sensor's bsNo (S%%). If two sensors have the same coordinates, the colour code will be for the highest bsNo.    
**Note:** Only sensors below *maxSensors* will appear boxed. **N.B.** the **``H``** command will REVERSE the coding from b/s to s/b.  
**(The resistor colour code is 0:black 1=brown 2=red 3=orange 4=yellow 5=green 6=blue 7=violet 8=grey 9=white)**

### PROCESSING4 commands

**``W###``** &nbsp; will limit the image to\#\#\# rows wide/high(1-240) (default 240)

**``X###``** &nbsp; will start the image from column ###(0-319) (default 0) -uses the sensorCAM 'x' command.

**``Y###``** &nbsp; will initiate an image download starting at row ### (0-239) (default 0) -uses the sensorCAM 'y' command.

**``Z###``** &nbsp; will limit the image to ### columns (1-320) (default 320) -uses the sensorCAM 'z' command.

**``H``** &nbsp; will flip/mirror subsequent images horizontally. **& reverses bsNo sensor colour code to s-b**

**``V``** &nbsp; will flip/mirror subsequent images vertically. (V + H effectively rotates image 180 degrees)

**``R``** &nbsp; will cause a firmware reset of the sensorCAM via the DTR line via. the USB interface. CAM will enter a wait mode for confirmation.  Reset can be aborted with command **``aw``**(Abort&Wait). **Ctrl-R** Resets CAM instantly.

!!! note "NOTES"
    1. The above commands ARE CASE SENSITIVE. They are recognized by Processing 4 as non-sensorCAM commands and processed in the monitor/PC. Commands **``X``**, **``Y``** & **``Z``** in turn automatically issue related sensorCAM commands **``x``**, **``y``** & **``z``** respectively, with appropriate parameters.  The **``Y``** command suspends sensorCAM imaging, holding a single "frozen" frame until a terminating command ('yy') is received.

    2. If you use **``H``** to mirror, the colour coding for boxed sensor number (bsNo.) has to be read right to left.

    3. **WIth sensorCAM.pde versions below 208, do not flip image before creating new sensors as cursor coordinates do not flip!** Version 208 resolves this.
    
    4. **Ctrl-E** toggles enable/disable echo of typed commands to the monitor/log file. It can replace the user's focus on the CAM image Cmd: window. **``YO``** should toggle the verbose mode. The command **``Y``** images from row 0 by default.
    
## 7 Wiring Requirements

Refer to **Figure 6** and [Appendix J](#appendix-j) for alternate solutions for connecting sensorCAM to an i2c bus for remote control. For initial testing from a PC, the basic ESP32-CAM-MB or Wrover-CAM (**CH340** based USB interface) could be sufficient via. USB.  With i2c, take care to use level shifting (PCA9515A or Endpoints) if using a Mega CS or 5V i2c bus.

The ESP32-WROVER-DEV board is a good alternative to the original ESP32-CAM-MB. The slightly bigger CAM will be a little more convenient with the ESP32S Expansion board. This 38 pin expansion board with 5V regulator is poorly described in the video below. **IGNORE PRESENTERS DESCRIPTION OF HIS FAULTY 5V REGULATOR past the 5minute mark**.  With NO Wrover, verify the regulator gives 5V from 9V at the barrel jack and remove power before inserting or removing the Wrover.  For want of a better video...

[ESP32S 38P/V4/ Expansion board](https://www.youtube.com/watch?v=AP_CX-SFPAQ)

The sensorCAM typically requires a long i2c cable for connection to the CS.  If the CS uses a 3.3V i2c bus, the length may be handled with use of an LTC4311 "terminator" to drive the extra length.  If the CS has a 5V i2c bus it must use a level shifter via an Endpoint or PCA9515A (refer [Wiring Requirements](ex-sensor-manual.md#7-wiring-requirements)

For long distances to sensorCAM, the recommended hardware interface to an **EX-CommandStation** is currently the **Sparkfun Endpoint** system (**Figure 6.** & [APPENDIX&nbsp;F](#appendix-f)) which permits the i2c bus to be run over long standard Cat5 twisted pair cable.  It can also carry the required raw power supply. The Sparkfun Endpoints are used **in pairs** and can cater for voltage shifting between 5V Command Stations (e.g. Mega) and 3.3V sensorCAM as required. For a simple off-the-shelf arrangement, an ESP32-WROVER-DEV CAM with a cheap ESP32S 38P Expander board (including regulator) can be linked to an Endpoint with 4 Dupont wires for a working CAM system on the end of a cat5 cable of considerable length as indicated in **Figure 6** & [APPENDIX&nbsp;J](#appendix-j), needing only a remote, preferably electrically isolated(floating), 7-10Vdc 0.5A power supply and a matching endpoint on a Command Station.

!!! note "NOTE:"

    1. For a cheaper solution, use the CAM and Expander with a LTC4311 for a shorter reach with either esp32-CAM or Wrover-CAM powered via USB.  
    2. The Sparkfun Endpoint may also need a jumper cut or joined for i2c bus isolation and voltage level matching to the Command Station.

The SensorCAM software has been almost exclusively tested on the ESP32-CAM-MB. The original prototype was fitted with some enhancements that may not be needed for the user's application.  However, at least one "super bright" LED (the "programmable nLED") is recommended for convenience to visually indicate when a bank sensor is "tripped". Connect LED between 3.3V via a resistor (~470R) to GPIO14.

The ESP32-CAM reset button, remotely mounted on CAM, may be difficult to access. To reset the device, two options need to be available. These can be via software command, either from the attached USB monitor, or i2c connected Command Station, or via a power supply induced reboot. A (Reset) switch at an ungrounded PSU ("wall-wart") 7-9V supply is recommended independent of the CS supply. The USB connection is needed to set up the sensors initially and view images, but should be able to be disconnected once setup testing is complete.  Some esp32's may need a 1uF or 2.2uF on the reset pin for reliable reset.

!!! note "NOTE:"

    **Care is needed as the WROVER CAM has 40 pins (not 38) but the spare end Gnd and Vcc can remain disconnected (cut off?).**

![ESP32 Wrover CAM with Sparkfun Endpoint](../../_static/images/ex-sensorcam/esp32-wrover-LTC4311.png)  
**Figure 6 &nbsp; ESP32 WROVER-CAM and interface**

## 8 Host Communication

### 8.1 Introduction

The operation of the railway depends on a Control Station that polls the sensorCAM for sensor states. This might be a dedicated Arduino Mega 2560 for example. It might be an **EX-CSB1** Command Station running DCC-EX and **EXRAIL** software. If the sensorCAM is powered up with default settings (from EPROM), or adjusted by the user at the start, the program need only talk to sensorCAM over an i2c bus using the commands a,b,i,l & o for example, or it may be more sophisticated, providing a command channel from a Control Station monitor to the sensorCAM to enable most configuration commands via the i2c bus.

The I2C bus is running at 100kHz on the prototype software. It has not been tested at any higher speed yet. It has been running fine over a 10m long I2C bus to the master microcontroller (CSB1, Mega or others).

### 8.2   DCC-EX EX-CS

Setting up a **DCC-EX** **EX-CommandStation**, should you have one, requires configuration details placed in files *config.h* and *mySetup.h* along with a driver *IO_EXSensorCAM.h* and *myAutomation.h*. These must go in the directory containing file CommandStation-EX.ino. Refer to [APPENDIX&nbsp;H](#appendix-h) for installation details.  *EXSensorCAM.h* code mirrors the sensorCAM command set with a few exceptions.  Imaging and graphic placement is not available.  Functionality was added using the DCC-EX sensorCAM native command `<N>` format.

### 8.4 Monitor Lighting

Stable good lighting is needed.  Gross Lighting changes will have two effects, namely cause trips of most sensors and stop automatic reference refreshes, it may be wise to include monitoring for this eventuality by detecting and setting an "alarm" state. The reference sensor (S00) is automatically re-referenced every 6.4 seconds so will indicate a fault-trip for a maximum of 6.4 seconds. All other sensors will continue to indicate a trip until the user resets the references with an r00 (having checked all unoccupied). See full manual for creating a fault LED indicator.  PLED uses GPIO14 and QLED uses GPIO32 (Wrover).

## APPENDIX A

### CAM Command Summary

[full manual](ex-sensor-manual.md#appendix-a)

rev 14JUL25

#### Introduction

Up to 10 banks (0-9) of sensors. Each bank can have up to 8 enabled sensors (0-7), i.e. Bank/sensor (%%) up to '97'.  Array *Sensor\[n]* holds coordinates(rx) of sensor n.  Sensors are grouped into banks(b) of sensors(s). e.g. bsNo 6/7 identifies bank 6, sensor 7 (n=8x6+7=55=067). Sensors are undefined if coordinates(rx) are set to 00. They are disabled if *SensorActive\[n\]* is set to false.  
If a sensor detects differences, then any output LED (e.g. *pLED qLED*) assigned to the associated Bank of sensors should turn ON.  
On reset (power-up), reference grabs are taken for all defined (in EEPROM) sensors, and then enables them.  
To define a sensor, use ``a`` command,  Processing4, or (outdated method) a bright LED on the desired spot and dim lighting with a "scan" (``s%%``). Save in EEPROM (``e``). SensorCAM uses RGB565 image format which is incompatible with JPG, so auto reboots between SensorCAM or webCAM modes occurs.

#### Native CAM Commands

**`a%%[,rr,xx]`** **enAble** *Sensor[%%]* & refresh *Sensor_ref[%%]*, *cRatios* etc. 4x4 from latest image frame. **(Note 20)**

**`b#[,$]`**&nbsp; &nbsp; **Bank** # sensors. Show which sensors OCCUPIED(in bits 7-0).(1=occ.) [ **$** sets *brightSF* to $]

**`c$$$$`**&nbsp; &nbsp; **\* reCalibrate** camera CCD occasionally and grab new references for all enabled sensors(Beware of doing this while any sensors are occupied) **N.B.** Obstructed sensors will later need an **r%%**. Check all bank LEDs are off AND check all sensors are unoccupied before recalibrate. Can set AWB AEC AGC CB through $$$$ e.g. c0110  
Also able to change default setting for Brightness, Contrast & Saturation with extra digits e.g. c$$$$012

**`d%%[#]`**&nbsp; **\* Difference** score in colour& brightness between Ref & actual image. [Show # grabs]

**`e`** &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; **EPROM** save of any new Sensor offset positions, pvtThresholds, new twins and 5 default parameter settings.

**`f%%`** &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; **\* Frame** buffer sample display. Print latest bytes in *Sensor_ref[%%]* & Sensor S%% positions.

**`g`**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; **\* Global ov2640** Status. Displays current settings available in webcam (sensor & video mode).

**`h$[,#]`**&nbsp; **\* Help(debug)** output.  **h9**  to turn all OFF,  **h0**  turn ON detailed USB output. '**h7,#**' "Waits" (w) on a bank# trip.

**`i%%[,$$]`** **Info.** on S%%.  Status(enabled/occupied), position(r,x), any twin(S$$), pvtThreshold & brightness.

**`j$#`** &nbsp; &nbsp; &nbsp; &nbsp; **\* adJust** camera setting $ to value # and display most settings (as for '**g**'). '**j**' alone lists options for $\#.

**`k%%,rrr,xxx`** \* set **coordinates** of Sensor S$$ to row: rrr & column: xxx. Follow with  **r%%**. Verify values with **p$**.

**`l%%`** &nbsp; &nbsp; &nbsp; &nbsp; (Lima) **Latch** sensor S%% to on(1=occupied & also set *SensorActive[%%]* false to disable sensing.

**`m$[,%%]`** **\* Minimum** $(1-4) sequential frames over *Threshold* to trigger/trip sensor. Configuration list**(Note 14)**

**`n#[,%%]`** &nbsp;**nLED** bank Number assigned to the programmable status *nLED*. [ **n10,%%** will set *minSensors* ].

**`o%%`** &nbsp; &nbsp; &nbsp; &nbsp; (Oscar) force **Off** sensor%% (0=UN-occupied, LED off) Also set *SensorActive[##]* false to disable updating.

**`p$`**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;**\* Position Pointe**r table info for banks 0 to $ giving DEFINED sensor r/ x\) positions.  p%% shorter.

**`q$`**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;**\* Query** bank$, to show which sensors ENABLED(in bits 7-0). 1=enabled. **q9** gives ALL banks.

**`r%%[,0]`** **Refresh** Average *Sensor_Ref[0%%]*, enable & calc. cRatios etc. [**r%%,0** refreshes block S%0 to S%%]

**`r00`** &nbsp; &nbsp; &nbsp; &nbsp; **Refresh** Average Refs etc. for ALL defined sensors. Ignores enable[]. Sensor[00] reserved for brightness ref.

**`s%%`** &nbsp; &nbsp; &nbsp;**\* Scan** for new location for sensor  S%%(00-97). If found, records location in *Sensor[0%%]*. **(Note 12)**

**`t##[,%%]`** **Threshold** level##(31-98 only) set as default. [**`t##,%%`** sets the *pvtThreshold* for S%% (**t0,%%** clears)]

**`t##`** &nbsp; &nbsp; &nbsp; &nbsp; **Tabulates** \#\#(2-30 only) rows of scroll data (continuous scroll toggled off) **Note:** `t1`** toggles scroll on/off.

**`t1,%%`**  &nbsp; &nbsp; **Trash** 1 entire bank of *pvtThresholds*. Use ``t1,99`` to clear ALL banks (0-9). **Note:** **t99** lists all *pvtThresholds*

**`u%%`** &nbsp; &nbsp; &nbsp; **\* Un-define**/remove sensor %%  (Sensor S%%=0 & set DISABLED) **u99** for ALL. ``e`` will erase from EPROM.

**`v[#]`** &nbsp; &nbsp; &nbsp; **Version/Video mode** [**v1** reboots into webserver mode. **v2** connects to 2nd (alt.) router ssid.]

**`w`**&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; **\* Wait** for new command line (\\n) before resuming sensing (handy to freeze display data scroll - ref.**`t1`** toggle)

**`x###`** &nbsp; &nbsp; &nbsp;\* selects first pixel column(0-319) & **`z###`** selects image width (### columns(1-320)) for imaging.

**`y###`** &nbsp; &nbsp; &nbsp;\* selects first row for image and initiates a binary data dump for that row (header + #x2 bytes) using rgb565.  
  &nbsp; &nbsp; &nbsp; &nbsp; This command starts a process that must, after a series of `y` commands, end with a terminator of `yy`.

**`R`** & **`F`** &nbsp; &nbsp;\* **Reset** commands- will Reset CAM and initiate the Sensor mode. Both Finishes the WebServer mode.

**`\%%,#,$`** &nbsp; &nbsp;linear sensor bank conversion starting with **S%%**  and using r,x step sizes of **#,$**(0-31) Slope "down-right".

**`/%%,#,$`** &nbsp; &nbsp;Convert bank to linear sensor starting with S%% as for '\\' but line will slope "down-left" (-deltaX).

**`&`** &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;**statistics** histogram on trips and potential trips since last ``&``, then reset counters and start another sample process. The table gives number of single highs, double highs etc. and totals for No. of frames/run time

**`@##`** &nbsp; &nbsp; &nbsp; &nbsp; \* set the "occupied" symbol in the scroll to ASCII character \#\#. Default is 35("#") Arduino IDE **@12** is bolder!

**`+#,$`** &nbsp; &nbsp; &nbsp;\* add offset(\# pixels) in $ direction to re-centre sensors after any drift in CAM alignment. $(0-7) for N-NW

&nbsp; &nbsp; &nbsp; * These commands typically for diagnostic/setup use only. They wait for a line feed or command to resume.

!!! note "Note:"

    The value of "bs"(80 sensors 0-79dec) is printed in several formats. For data entry, bsNo format %% (e.g. 47) is bank/sensor, so bsn=8*4+7=39dec.(vpin). S47 may be printed as(char) 47, 4/7, (octal) 047,(or hex 0x27) depending on context. Debug output likely uses OCT(or HEX). Note: OCT 0107=8/7, 0117=9/7.

### Startup Notes

1. Normal power up reset will initiate Sensor mode, as will the 'R' command, and uses EPROM data settings.
2. Sensor mode startup flashes white LED at 10Hz after \~10 seconds, and exhibits a "flicker" at ~20 seconds.
3. Requested (v1) WebServer mode reset will flash LED at  ~3seconds and again (brighter) at ~8 seconds.
4. After the 8 second flash the Webserver will be operational at web address 192.168.0.xx (xx from display).
5. If the OV2640 camera or WiFi fails to initialize, the CAM resets and may restart/revert into Sensor mode.
6. If USB FTDI/MB is removed or not connected to PC, then WebServer may fail/reboot. Power issue?

### I2C command Notes

**(EX-CS may exhibit small variations & reduced command functionality refer [APPENDIX C](#appendix-c))**

1. The same commands are valid from an I2C Master Arduino, but there are some variations.  
2. The commands with asterisks normally pause CAM execution so the operator can read USB output on a monitor screen. The same commands from I2C DO NOT wait for a new line, with the exception of 'w'.  
3. Commands b,d,i,m,p,q&t can return data to the I2C master Arduino(Mega). This data is delivered if the master calls a *Wire.requestFrom(addr,#)*; following the command, from the slave CAM address 17(0x11).  
4. The I2C data returned(after header byte) is in binary bytes and in a format depending on the last command.  
5. Header byte[0] is the ASCII command character (b,d.i,m,p,q,or t) or an error code(OxFE) if no valid data.  
6. If the error code is generated, it is followed by the last received (inappropriate) command string.  
7. ``b$`` command returns $+1 sensor status bytes for bank$,$-1 etc. down to bank 0. 'b' defaults to 'b9'(all).  
8. ``d%%`` command returns 4 data bytes with binary values for *bsn*, *maxDiff*+*bright*, *maxDiff* & *bright* in that order.  
9. ``i%%`` command returns 2 data bytes: byte[1]= *bsn* and byte[2]=0 if unoccupied or 1(true) if occupied. (+ more)  
10. ``p$`` command returns Byte[0] header + count +3 data bytes per enabled (bank$) sensor + parity (max 27 bytes).  
11. ``q$`` command returns $+1 bank sensor enabled status bytes for bank$,$-1 etc. down to bank 0. 'q' defaults to 'q1'  
12. ``s%%`` Scan looks for a bright LED on a dimmer background. The LED should be placed on the desired sensor position. This old method of placing sensors is not recommended. The Scan command is the last resort when USB is unavailable.  
13. ``t##[,%%]`` command. initially sends CS the old *threshold* value (i.e. BEFORE change in the case of t\#\#). Also returns sensor scores(*bpd*) in 2-byte pairs with MSB set so: *bsn*(+0x80 if undecided) & *bpd*(+0x80 if OCCUPIED). Byte[0]header;[1]threshold;[2]S00bpd;[3]bsn;[4]bpd;[5]bsn;[6]bpd etc. Ends with bsn=80 (max 15 enabled)
14. ``m$,%%`` sets *maxSensors* to %% (USB or i2c) (as can h%% (%%<98)). m0,1%% sets *minSensors*. Data sent to screen is bound between min and maxSensors. Extra parameter status bytes added to i2c bus for display.  
15. The ``"`` character is just a null command. Used before R, d & t to prevent BCD Mega itself pre-interpreting them.  
16. N.B.: The ESP32-CAM uses old ESP32S which has I2C limitations. It has a "pipeline" for returning data which results in a delay in response. i.e. the first request after a command will return OLD data. A SECOND request should return the desired data described above. A third or fourth request may return updated data.  
17. Some commands take time to complete, as command processing can only happen once per 100mSeconds (i.e. the frame rate of the CAM). The I2C master should allow for latency in response where necessary. Place a ``DELAY(400)`` between all ``PARSE("<N....>")`` **EXRAIL** commands.  
18. Data requested over i2c may have a parity byte appended, and a check byte in byte[31].  
19. NOTE Automatic updating of ref image of unoccupied sensors now starts after last SUS (suspend) indicator.  
20. ``a%%,rrr,xxx`` performs extended 'create sensor' equivalent to  ``k%%,rrr,xxx`` + ``a%%`` + ``r%%`` for new sensor S%%  
21. Connection to DCC-EX Command Station has command. variations. See APPENDIX C for revised command detail.

## APPENDIX B

### Optimising Sensor Response

[full manual](ex-sensor-manual.md#appendix-b)

In the situation where sensors may be tripping undesirably, there is a range of adjustments that can be made to find a satisfactory operating point. Some have disadvantages that need to be considered and compromises may be necessary.

1. First step is to refresh the sensor reference image. Try command: ``r00``, or ``r%%`` for a single sensor. This may be necessary after any disturbance to the environment such as changed lighting.

2. Check the "Diff" scores on the scrolling display. After a refresh they should be in the range 32-37 for normal operation. If occasional trips occur, one remedy is to increase the threshold with command: ``t46`` say. Increasing the threshold reduces the sensitivity to low contrast objects (e.g. black over brown) If unoccupied Diff scores are consistently 32-35, reduce threshold for greater sensitivity.

3. Is the lighting adequate? **Steady** muted daylight is ideal. Beware of rotating fans and other moving shadows (clouds?) (Note: may need to consider extreme case of mains induced ripple from 50/60Hz LED/fluoro lighting-to be discussed later) Brighter stable lighting means reduced "noise".

4. Sensitivity to electrical "noise" can be reduced by increasing the "*min2trip*" parameter to 3 consecutive frames using command: ``m3`` (default is m2). However this increases response time by 100mS.

5. You can create a "Twin" sensor for a "second opinion" by placing a Second Sensor S\$\$ on the track adjacent to the primary sensor S\%\% (3-4 pixels away) by using the command: ``a$$,123,234`` selecting the position from that of the primary sensor (obtained from command: ``i%%``) To avoid increasing response time, use a twin bsNo LOWER than the primary sensor (possibly in a "reserved" bank, perhaps a matching bsNo in that bank). This twin S\$\$ can be assigned to the primary sensor S\%\% with the command: ``i%%,$$`` The primary sensor will not trip unless the twin agrees. This suppresses pixel noise spikes.

6. Check that there isn't anything elsewhere in the field of view that is moving and could trigger the auto exposure in the camera. e.g. spectators near the edge of the field of view.(It is possible to change camera ov2640 module settings with ``j`` and ``c`` commands, but this can be a frustrating experience and needs considerable practice as some settings interact and can be order dependent)

7. Make sure you do a refresh/record reference (``r``) after any changes or the benefit will be obscured.

8. Is the camera steady? No vibration or movement since the last reference images (``r``)?

9. There is a 2-frame (experimental) averaging applied to low bank sensors (currently 0-2) This can be extended to cover all banks, if desired by increasing CAM parameter *TWOIMAGE_MAXBS* above 3/0

10. There has been poorer behaviour observed with sensors placed near the edge of the frame. They seem to experience more electrical noise than mid-frame sensors and may need extra attention.

11. A statistics function can be obtained to see how bad spurious tripping is. The ``&`` command gives a table of stats accumulated since the previous ``&`` command. May be useful. HINT: You can compare two or more sensors with different settings on the same spot. Accumulate data with no genuine trips.

12. Consider whether a pixel may be faulty or unduly noisy. Try another nearby sensor position.

13. If necessary, enhance the brightness of the Sensor location with light colour or a small reflector.

14. It is possible to set private thresholds on individual sensors if other solutions inadequate. (``t##,%%``)

15. Consider adjusting *brightSF* \(\$\) if colour contrast is generally poor \(``b#,$``\) default 3, try 1-5.

16. In some situations, repositioning sensor slightly to include loco shadow will give extra sensitivity.

17. Consider repositioning CAM for better oblique view angle giving more contrast for better detection, catching sides of coaches/wagons, shadows and some trackside references.

18. Consider a beam break enhancement by placing an IR led between rails at the sensor position (power from DCC track?)

## APPENDIX C

### DCC EX-CS commands

[full manual](ex-sensor-manual.md#appendix-c)

The file *CamParser.cpp* has been added to the CS specifically tailored to provide a mechanism for the CS to send commands more easily than by using the clumsy diagnostic command style ``<D ANOUT vpin parm1 parm2>``. The CS Native CAM command format is ``<N c [parm1] [parm2]>`` where command character '**c**' can be any of those listed below. Generally, to effect changes in sensorCAM, the CAM must be in the run mode (flashing).

The base vpin address defaults to 700 but one can use the *#define SENSORCAM_VPIN ###* for another value (in *config.h*). With 2 to 4 CAM's, use ``<N C #>`` (1-4) when a switch is needed. The CAM# may also be placed, if defined in *config.h*, prefixing the sensor bsNo.
e.g. ``<Ni 2%%> <Nr 2%%>`` also ``<Nm 200> <Nf 212> <Nt 243>``

### Command list

| Native CS<br>command | Example | Native<br>CAM cmd. | sensorCAM action<br>(some only return "ACK OK" to CS) |
| --- | --- | --- | --- |
| **`<N>``** | <N\> | n/a | Lists current & alt. defined CAM baseVpins. |
| **`<N C ###>`** | <NC 600\> | n/a | **CAM** base vpin(>99) for following commands OR <NC #\> selects CAM # (1-4) |
| **`<N a %%>`** | <Na 12\> | a12 | **enAble** sensor S%% (bsNo). |
| **`<N a%% row col>`** | <Na&nbsp;12&nbsp;32&nbsp;43\> | a12,32,43 | **enAble** & also set new coordinates for sensor bsNo & refresh |
| **`<N b bank#>`** | <Nb 1\> | b1 | **Bank** sensor states(all 8).(used by IFGTE() ATLT() e.g. to locate loco). |
| **`<N e>`** | <Ne\> | e |**EPROM** write any changed settings to sensorCAM EPROM. |
| **`<N f %%>`** | <Nf 12\> | f12 | **Frame image** pixel data for Sensor_ref[%%] and sensor666[%%] (RGB bytes). |
| **`<N F>`** | <NF\> | F (or R) | **Forced Reboot**, restoring sensorCAM sensor mode & EPROM defaults. |
| **`<N g>`** | <Ng\> | g | **Global ov2640** camera module status (sensorCAM monitor). |
| **`<N h %%>`** | <Nh 30\> | h30 | set *maxSensors* to limit display to below sensor S%%. Also **h** for **Help** |
| **`<N i %%>`** | <Ni 12\> | i12 | **Information** on sensor bsNo state, position & twin (0=No twin). |
| **`<N i %%[ $$]>`** | <Ni 12\> | i12,02 | **Info.** & assigns new twin sensor(S$$) for "second-opinion" on S%%. |
| **`<N j $ #>`** | <Nj B 2\> | jB2 | **adJust** ov2640 parameters($)(Brightness, Contrast etc)(values 0-2 only). |
| **`<N l %%>`** | <Nl 12\> | l12 | (lima) **Latch** output state of sensor bsNo to 1 & disable. |
| **`<N m $[ %%]>`** | <Nm 3 20\> | m3,20 | **Min/max** *min2trip*(1-4) frames [*maxSensors*] **<NM\> shows CAM parameters** |
| **`<N n $[ %%]>`** | <Nn 1 10\> | n1,10 | set **nLED**= bank $ [set *minSensors*=%% to limit display range] <Nn v\> verifies. |
| **`<N o %%>`** | <No 12\> | o12 | (oscar) **Zero** output state of sensor bsNo. Reset to 0 & disable. |
| **`<N p %%>`** | <Np 1\> | p1 | **Positions**(r,x) of all enabled sensors in bank are listed. |
| **`<N q #>`** | <Nq 1\> | q1 | **Query bank**# enabled states of sensors (0 indicates sensor disabled). |
| **`<N Q>`** | <NQ\> | n/a | **Query** state of all sensorCAM Sensors |
| **`<N r[ %%]>`** | <Nr 12\> | r12 | **Refresh Reference** image for sensor S%% (default ALL=r00). |
| **`<N s %%>`** | <Ns 12\> | s12 | **Scan** image for brightest spot and set S%% to center that pixel. |
| **`<N t ##[ %%]>`** | <Nt 43 12\> | t43,12 | **Threshold** displayed, sets global *threshold* (32-98) [sets a *pvtThreshold*]. |
| **`<N t ##>`** | <Nt 10\> | t10 | **Tabulate** ## (2-31) rows of scroll data similar to CAM scroll. |
| **`<N t # %%>`** | <Nt 0 12\> | t0,12 | **Trash** pvtThresholds. **<Nt 0 %%\>** individually, **<Nt 1 %%\>** for bank, **<Nt&nbsp;1&nbsp;99\>** trashes ALL pvtThresholds.  **<Nt&nbsp;99\>** lists ALL pvtThresholds. |
| **`<N t 1>`** | <Nt 1\> | t1 | **toggles** scroll on/off. |
| **`<N u %%>`** | <Nu 12\> | u12 | **Undefine** and disable sensor bsNo(erase coordinates). **<Nu 99\>** for ALL |
| **`<N v[ #]>`** | <N v 1\> | v1 | **Video** mode(1-2) invoke webCAM, or alt webCAM with v 2. **v** for **version** |
| **`<N w>`** | <Nw\> | w | **Wait**. Stop/start CAM imaging (flash), status sensing & streaming. |
| **`x y z`** | | | Reserved for binary export for Processing 4 images |

!!! note "Notes:"

    The 'i' command prints bsNo(bsn) where bsn/vPin offsets range from(7)00 to(7)79(e.g. baseVpin address 700).  
    Some commands return previous(old) values then update sensorCAM. Use <Nm\> to confirm change.  
    Space after <N is optional, as is capitalization of command. e.g.<N t 42\>=<NT 42\>,<N&nbsp;r&nbsp;00\>=<NR\>  
    Multiple CAM selections can be achieved by config.h entry and use of a prefix on param1 e.g.<Ni&nbsp;212\> for CAM 2  
    For commands to work fully, need latest *CamParser.cpp*, CS driver(*IO-EXSensorCAM.h*) & *sensorCAM.ino*

## APPENDIX E

### Tabulated DCC-EX-CS ID's

[full manual](ex-sensor-manual.md#appendix-e)

**Table E** below shows the colour code used to identify sensors on the Processing 4 track image.
For example, sensor S12 has a bsNo 1/2 for which the colours are Brown/Red (seen on sensor box edges).
For CAM number 1, the full CS sensor S12 ID is 112 when used in CS native ``<N>`` commands such as ``<N i 112>``
The use of the CAM # can be optional.  If only one CAM is installed (or selected), ``<Ni 12>`` is sufficient.
For **EXRAIL** it can be tested so: **AT(CAM 012)** where the vpin is invisibly calculated as (700+012).
**N.B.** The use of the '0' after CAM is essential in EXRAIL.
The colour code is the standard resistor value colour code for 0-9.

Under normal circumstances if the **EX-CommandStation** has been configured as per the installation instructions, there is no need to refer to the vpin of any Sensor.  They are all relative to the baseVpin of the CAM.

The full ID consists of CAM number #-bank-sensor or #bs. Each bank(0-9) contains 8 sensors(0-7)  
vPin is the (CAM number # baseVpin) + 0bs,  bsNo skips id's ending in 8 or 9.  (e.g. 700 + 012 = 710)  
vPin is the base/first vPin number (e.g. 700) + DEC.number(_bsn_) in the conversion table below.

![Sensor Code Conversions](../../_static/images/ex-sensorcam/sensor-code-conversions.png)  
**Table E &nbsp; &nbsp; Reference Sensor ID to colour code conversion table**

## APPENDIX F

### Hardware Interface

[full manual](ex-sensor-manual.md#appendix-f)

!!! note "Note:"
    This Appendix focused on the **ESP32-CAM-MB** implementation, but for WROVER-CAM information now refer to the full [sensorCAM Manual](ex-sensor-manual.md#appendix-f)  
    The information below in [APPENDIX J](#appendix-j) pertains mostly to the newer WROVER-CAM, as mentioned in **Section 7**, **Figure 6** 


## APPENDIX H

### Notes on use of EX-RAIL

For tips and techniques of reading sensorCAM sensor states, refer to [full manual](ex-sensor-manual.md#appendix-h)

## APPENDIX J

### WROVER-CAM Wiring

[full manual](ex-sensor-manual.md#appendix-j)

!!! note "NOTES on using 40-pin WROVER CAM and 38-pin breakout board"

    1. The WROVER-CAM offers potentially the simplest commercially available hookup for any sensorCAM.

    2. Software configuration: add *#define CAMERA_MODEL_WROVER_KIT* to bottom of configCAM.h

    3. 2x"Spare" (USB end) Vcc and GND pins not used with the 38 pin expansion board shown. (pins could be removed for safety)

    4. As with other esp32 devices, adding 2.2uF capacitor between reset (EN) pin and gnd ensures more reliable power-on reset.

    5. Optionally add a super-bright green LED and 330R resistor from 3.3V to GPIO14 for programmable nLED indicator.

    6. There is no white "flash" LED on Wrover-CAM but, in sensorCAM mode, the on-board blue LED flashes instead. (GPIO2)

    7. Limit Vin barrel jack to 7-10V max to avoid overheating the 1117C 5V regulator. (Vne= 16V)

    8. The breakout board USB connectors are for an optional 5V power source ONLY. No comm's.

####Mounting and Power

The sensorCAM can be Reset remotely by software or by cycling the power supply. The CAM MUST be rigidly mounted as it's response to any image vibration can trip sensors. It is best not moved after sensor location programming as precise realignment could be tedious. It is, however, advisable to make guides or jig arrangement to at least be able to remove (for maintenance) and return with minimal misalignment to cover the same field of view. The inconvenient LED method of placing/positioning sensors may be necessary if a long USB cable is impractical. A 5m buffered USB cable might be advantageous. Even so, setup programming or imaging over a long USB cable may not be satisfactory.

The sensorCAM needs a regulated power supply independent of the i2c bus SDA,SCL & GND cable. It requires 1A 9V DC supply (wall-wart/plugpack PSU). The cam typically runs on 200mA but 500mA in wifi mode.  A 5V regulator is needed at the CAM itself to feed the on-board 3.3V regulator.  The 5V regulator is included on the recommended 38pin expander board. Limited 3.3V is available from the CAM itself.

####I2C and LTC4311

The ESP32 CAM drives GPIO pins with 3.3V logic. This may well be incompatible with the master l2C signals at 5V. It is essential that appropriate voltage level shifting and buffering is used where necessary (e.g. PCA9515A). Unbuffered I2C is limited in range but an LTC4211 or Sparkfun differential i2c driver/endpoint may be used to achieve longer lengths (and voltage shifting) if needed.

**If using a 3.3V processor such as the CSB1**, it may be adequate to have a direct i2c connection to an existing i2c branch with an LTC4311 terminator/buffer at the CS to boost signal rise times and range, keeping the total i2c segment within allowable length limits.  This may mean using a multiplexer port to limit segments to workable lengths, as the run to the sensorCAM is a significant additional length to any existing i2c bus.  Be sure to check that sufficient pullup resistors are on the data lines to 3.3V only. 

![Typical Mega with ESP32 CAM](../../_static/images/ex-sensorcam/esp32-wrover-LTC4311.png)

####I2C Sparkfun Endpoints

For long lengths, the Sparkfun endpoint is perhaps the best overall solution at this stage for driving one (or more) sensorCAMs. It provides greater lengths of cable without extending the Command Station i2c local bus. The endpoints are used in pairs, connected by a long (<100m) differential pair cat5 cable providing power and communications. It can provide buffering, level shifting and power delivery, but care is needed at the CS end to avoid over-voltage damage. It is suggested, with a 5V CS, that the Endpoint pullup 0-1 jumpers at the CS end be cut for safety. The sensorCAM Endpoint default pullups are needed for the 3.3V CAM i2c bus. The CS Endpoint requires 3.3V power (from the CS) and a separate (7 to 9V) DC supply for the expander Regulator & CAM.

![ESP32 Wrover CAM with Sparkfun Endpoint](../../_static/images/ex-sensorcam/esp32-wrover-with-endpoint.png)

**Wiring for Differential drive with 3.3V CS BUS:**

![Differential Drive 3.3V Only CS](../../_static/images/ex-sensorcam/differential-drive-3v3-only-cs.png)

For further information on use of two Sparkfun Endpoints to connect a CAM over differential pair cable to the CS refer to [full manual APPENDIX F](ex-sensor-manual.md#c-for-33v-differential-drive-33v-cs-i2c-bus)


####I2C and PCA9515A

Another option is to use PCA9515A with the Wrover-CAM connected as below, particularly with a 5V CS Mega to achieve voltage level shifting.  The wires from PCA9515A to the CAM can be up to 2m long if needed (with extra pullups) using twisted pairs (cat5?).  Use of LTC4311 with PSA9515A is not recommeded.

![ESP32 Wrover CAM with PCA9515A](../../_static/images/ex-sensorcam/esp32-wrover-pca9515a.png)


## APPENDIX K

### OV2640 Lens options

see [full manual](ex-sensor-manual.md#appendix-k)
